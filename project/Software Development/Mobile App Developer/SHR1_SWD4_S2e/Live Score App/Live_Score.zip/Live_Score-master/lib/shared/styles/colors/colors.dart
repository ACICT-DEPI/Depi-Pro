
// ignore_for_file: unnecessary_const

import 'package:flutter/material.dart';

Color? defaultColor =  Colors.pinkAccent;
Color? premierColor = const Color.fromARGB(255, 58, 0, 61);