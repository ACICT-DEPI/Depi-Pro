// ignore_for_file: non_constant_identifier_names

import 'package:football_scores/models/user_model.dart';

UserModel? userModel;
String? UID;
