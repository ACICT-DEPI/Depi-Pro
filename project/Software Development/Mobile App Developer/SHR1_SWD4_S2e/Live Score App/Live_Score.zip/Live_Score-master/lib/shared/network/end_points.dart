// ignore_for_file: constant_identifier_names

const FIXTURES = 'fixtures';
const LEAGUES = 'leagues';
const ROUNDS = 'fixtures/rounds';
const Events = 'fixtures/events';
const Stats = 'fixtures/statistics';
const LINE_UP = 'fixtures/lineups';
const STANDINGS = 'standings';
