package com.example.football_scores

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
